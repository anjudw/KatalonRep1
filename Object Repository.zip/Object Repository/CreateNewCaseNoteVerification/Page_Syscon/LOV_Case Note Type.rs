<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>LOV_Case Note Type</name>
   <tag></tag>
   <elementGuidId>c572cbb2-5f7b-4ec1-9a46-64f2310d6ccb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#mat-option-203 > span.mat-option-text > li > span.ng-star-inserted</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Code'])[1]/following::span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>6690ae7f-1049-49f8-806a-a005d951559b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ng-star-inserted</value>
      <webElementGuid>9820fdbf-a7b9-4e4f-80a2-f0da968ab948</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Case Note</value>
      <webElementGuid>1bcff879-7be0-4520-90ce-10e7b8deae11</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mat-option-203&quot;)/span[@class=&quot;mat-option-text&quot;]/li[1]/span[@class=&quot;ng-star-inserted&quot;]</value>
      <webElementGuid>ba849d3f-ba58-447d-9739-19e05a85f786</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//mat-option[@id='mat-option-203']/span/li/span</value>
      <webElementGuid>15d309f8-acbe-4d76-9a57-652e9badb6ad</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Code'])[1]/following::span[2]</value>
      <webElementGuid>2551bd6a-52ee-4bb4-bcad-66daa0ba9113</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Description'])[1]/following::span[3]</value>
      <webElementGuid>2d862476-5092-4d32-8c3a-8b66171eb203</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CNOTE'])[1]/preceding::span[1]</value>
      <webElementGuid>f89c006c-8036-45c2-b90b-086060b418c2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Intake'])[2]/preceding::span[2]</value>
      <webElementGuid>341f6f7a-a0fb-400a-8861-007ec437f2c4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Case Note']/parent::*</value>
      <webElementGuid>fbb68c03-28dc-4b77-b6dc-986a7e512f36</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//mat-option[2]/span/li/span</value>
      <webElementGuid>64a58ad5-b0c1-481b-b9a9-7ab99a911bbc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Case Note' or . = 'Case Note')]</value>
      <webElementGuid>c637bfcd-e4e1-41f9-a9ab-2baeae4b1d56</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
