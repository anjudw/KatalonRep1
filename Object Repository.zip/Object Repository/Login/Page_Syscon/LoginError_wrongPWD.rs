<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>LoginError_wrongPWD</name>
   <tag></tag>
   <elementGuidId>e7cd6f23-42e1-43d4-811b-9fd7eb8249c6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@class='toastHeading']/h3[contains(text(), &quot;Error!&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@class='toastHeading']/h3[contains(text(), &quot;Error!&quot;)]</value>
      <webElementGuid>b2aeea62-e783-46e5-88d7-3a06c67ca935</webElementGuid>
   </webElementProperties>
</WebElementEntity>
