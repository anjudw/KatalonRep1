<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Logout</name>
   <tag></tag>
   <elementGuidId>9e909b96-dd5f-4d4d-a8c0-55cb59ffa67b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//button/span/mat-icon[@role='img' and @class='mat-icon notranslate mat-tooltip-trigger material-icons mat-icon-no-color']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//button/span/mat-icon[@role='img' and @class='mat-icon notranslate mat-tooltip-trigger material-icons mat-icon-no-color']</value>
      <webElementGuid>739a80e4-d8c1-4586-a24f-a30a00405295</webElementGuid>
   </webElementProperties>
</WebElementEntity>
