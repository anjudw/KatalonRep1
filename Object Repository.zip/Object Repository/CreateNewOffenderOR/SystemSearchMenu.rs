<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>SystemSearchMenu</name>
   <tag></tag>
   <elementGuidId>7101295a-adb5-4107-9ef5-ff9c8a74ea6e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[@class='mat-line dynamic-menu-text' and contains(text(), &quot;System Search&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[@class='mat-line dynamic-menu-text' and contains(text(), &quot;System Search&quot;)]</value>
      <webElementGuid>ac78009f-44f5-4005-a4ed-49a4165e8bb2</webElementGuid>
   </webElementProperties>
</WebElementEntity>
