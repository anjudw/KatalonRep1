<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>SexField</name>
   <tag></tag>
   <elementGuidId>82511451-167f-40fb-b727-ea266e7c40b1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//s4-lov [@domain='SEX']/ div/mat-form-field/ div/div/div/div/div/input[@type='text' ]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//s4-lov [@domain='SEX']/ div/mat-form-field/ div/div/div/div/div/input[@type='text' ]</value>
      <webElementGuid>cac84136-501c-4fe0-a700-0a709ffcb3d5</webElementGuid>
   </webElementProperties>
</WebElementEntity>
