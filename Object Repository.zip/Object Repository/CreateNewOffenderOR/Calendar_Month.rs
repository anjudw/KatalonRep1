<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Calendar_Month</name>
   <tag></tag>
   <elementGuidId>1b4462b8-9fcd-4e1f-a520-1f7929dcae09</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[contains(text(), &quot;MAR&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[contains(text(), &quot;MAR&quot;)]</value>
      <webElementGuid>9700ca1d-cc16-46d2-8d5c-e59aad3c90e3</webElementGuid>
   </webElementProperties>
</WebElementEntity>
