<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>NameMenu</name>
   <tag></tag>
   <elementGuidId>75599eee-37f4-4cf0-a613-be91addc07a2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//ul/li/mat-nav-list/a[@href='#/OSIOSEAR']/span/span/span[contains (text(), &quot;Name&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//ul/li/mat-nav-list/a[@href='#/OSIOSEAR']/span/span/span[contains (text(), &quot;Name&quot;)]</value>
      <webElementGuid>c5988291-6e23-4edd-afa4-ee8694af4941</webElementGuid>
   </webElementProperties>
</WebElementEntity>
