<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Calender_previous_arrow</name>
   <tag></tag>
   <elementGuidId>898d3070-fa7e-4172-bcc9-548188c797c7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//button[@aria-label='Previous 24 years']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//button[@aria-label='Previous 24 years']</value>
      <webElementGuid>f9b02dc4-4380-48aa-be4c-99db9999384f</webElementGuid>
   </webElementProperties>
</WebElementEntity>
