<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>SexField_LOV</name>
   <tag></tag>
   <elementGuidId>a9bfbb06-e27c-4bdd-8ffe-d1e74496e4a6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@class='lov-option-col-base ng-star-inserted' and contains(text(), &quot;M&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@class='lov-option-col-base ng-star-inserted' and contains(text(), &quot;M&quot;)]</value>
      <webElementGuid>04e0c4d2-2b9c-4e7a-a5f1-b17d4db3dba0</webElementGuid>
   </webElementProperties>
</WebElementEntity>
