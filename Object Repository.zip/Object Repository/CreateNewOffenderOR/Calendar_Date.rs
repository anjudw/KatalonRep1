<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Calendar_Date</name>
   <tag></tag>
   <elementGuidId>b8ac2554-7808-4eb9-b95e-da68df408ae9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[contains(text(), &quot;26&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[contains(text(), &quot;26&quot;)]</value>
      <webElementGuid>7c5009a8-31a8-48c1-8bcf-b3e63506410f</webElementGuid>
   </webElementProperties>
</WebElementEntity>
