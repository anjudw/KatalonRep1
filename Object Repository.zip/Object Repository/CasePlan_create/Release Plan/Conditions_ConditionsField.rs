<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Conditions_ConditionsField</name>
   <tag></tag>
   <elementGuidId>cc173a3e-0d0e-4b16-8063-5bc19a7bcddd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@col-id='commConditionCode' and @role='gridcell']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@col-id='commConditionCode' and @role='gridcell']</value>
      <webElementGuid>e3a4ea88-cb4c-4785-9d2d-70b3bbdaf947</webElementGuid>
   </webElementProperties>
</WebElementEntity>
