<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Conditions_LengthField</name>
   <tag></tag>
   <elementGuidId>33e4436e-252a-48b3-8592-e6bdb75b9904</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@col-id='length' and @role='gridcell']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@col-id='length' and @role='gridcell']</value>
      <webElementGuid>7374bd01-2855-43e9-a9d2-4f26a368d59b</webElementGuid>
   </webElementProperties>
</WebElementEntity>
