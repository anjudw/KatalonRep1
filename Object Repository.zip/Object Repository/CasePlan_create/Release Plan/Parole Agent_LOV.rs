<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Parole Agent_LOV</name>
   <tag></tag>
   <elementGuidId>6ad32a2f-3414-4aa5-8807-3bbf5143e741</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//li/span[2][contains(text(), &quot;6196&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//li/span[2][contains(text(), &quot;6196&quot;)]</value>
      <webElementGuid>8e2eac52-8ed0-40f5-82ce-5257d48d846f</webElementGuid>
   </webElementProperties>
</WebElementEntity>
