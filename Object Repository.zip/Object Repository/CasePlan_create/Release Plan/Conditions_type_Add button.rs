<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Conditions_type_Add button</name>
   <tag></tag>
   <elementGuidId>d7b28ad2-4eee-479d-83fd-aa0a9b883c7e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value> //s4-dialog-card[@screenid='OCUCONDI']/s4-dialog-card-content/mat-dialog-content/s4-panel/div/div/div/mat-expansion-panel/div/div/div/div/s4-grid/div/div[2]/div/div/div/div/button[@class='court-btn controls-btn add-btn']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value> //s4-dialog-card[@screenid='OCUCONDI']/s4-dialog-card-content/mat-dialog-content/s4-panel/div/div/div/mat-expansion-panel/div/div/div/div/s4-grid/div/div[2]/div/div/div/div/button[@class='court-btn controls-btn add-btn']</value>
      <webElementGuid>88a1b7bc-298f-4f61-a951-a6bed75f46ec</webElementGuid>
   </webElementProperties>
</WebElementEntity>
