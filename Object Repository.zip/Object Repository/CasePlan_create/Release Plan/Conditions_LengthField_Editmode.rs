<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Conditions_LengthField_Editmode</name>
   <tag></tag>
   <elementGuidId>ac23dbfd-c52b-43c1-80ed-d492cd90a14d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@col-id='length' and @role='gridcell']/grid-cell-editor-number</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@col-id='length' and @role='gridcell']/grid-cell-editor-number</value>
      <webElementGuid>c69e095c-5750-4bb2-ba52-855e16718bfe</webElementGuid>
   </webElementProperties>
</WebElementEntity>
