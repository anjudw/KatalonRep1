<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>CaseManagerfield</name>
   <tag></tag>
   <elementGuidId>9a98d6cb-01ca-4fc9-9ff4-8af80633232b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@col-id='caseManagerId' and @role='gridcell']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@col-id='caseManagerId' and @role='gridcell']</value>
      <webElementGuid>724b0cbf-387a-4b3e-a2f0-7c7fdb986d78</webElementGuid>
   </webElementProperties>
</WebElementEntity>
