<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Conditions_conditions_Add button</name>
   <tag></tag>
   <elementGuidId>38b9c2c2-1ef7-4ce3-9494-e78e2102e514</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//mat-dialog-container/app-ocucondi/s4-dialog-card/s4-dialog-card-content/mat-dialog-content/s4-panel[2]/div/div/div/mat-expansion-panel/div/div/div/div/s4-grid/div/div[2]/div/div[1]/div/div[1]/button[@class='court-btn controls-btn add-btn']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//mat-dialog-container/app-ocucondi/s4-dialog-card/s4-dialog-card-content/mat-dialog-content/s4-panel[2]/div/div/div/mat-expansion-panel/div/div/div/div/s4-grid/div/div[2]/div/div[1]/div/div[1]/button[@class='court-btn controls-btn add-btn']</value>
      <webElementGuid>20b03348-b6c5-40ab-93a9-22523f47f3a3</webElementGuid>
   </webElementProperties>
</WebElementEntity>
