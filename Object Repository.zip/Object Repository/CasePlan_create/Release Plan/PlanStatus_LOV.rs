<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>PlanStatus_LOV</name>
   <tag></tag>
   <elementGuidId>d133420f-0013-4abc-bbc4-d245cd7b2e93</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//li/span[contains(text(), &quot;INPRG&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//li/span[contains(text(), &quot;INPRG&quot;)]</value>
      <webElementGuid>95a34d4b-6ec8-4bd8-a8ab-f34ec79e0460</webElementGuid>
   </webElementProperties>
</WebElementEntity>
