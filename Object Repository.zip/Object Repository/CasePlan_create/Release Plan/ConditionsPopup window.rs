<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ConditionsPopup window</name>
   <tag></tag>
   <elementGuidId>352d2ff5-d849-4d39-86bb-d050cfcc3872</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//s4-dialog-card[@screenid='OCUCONDI' and @class='s4-dialog-card']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//s4-dialog-card[@screenid='OCUCONDI' and @class='s4-dialog-card']</value>
      <webElementGuid>3c89aa20-f893-4b6b-ae75-d99f1e1a8edb</webElementGuid>
   </webElementProperties>
</WebElementEntity>
