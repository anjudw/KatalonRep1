<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Plan Status Field</name>
   <tag></tag>
   <elementGuidId>abcf3b33-51c7-4cb9-aa99-752b78358d47</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@col-id='planStatus' and @role='gridcell']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@col-id='planStatus' and @role='gridcell']</value>
      <webElementGuid>a1599bfb-a733-43ad-964b-67e368753c48</webElementGuid>
   </webElementProperties>
</WebElementEntity>
