<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Condition_CategoryField</name>
   <tag></tag>
   <elementGuidId>8bf6b10e-386b-4aa5-ad56-c775a6199aa4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@col-id='categoryType' and @role='gridcell']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@col-id='categoryType' and @role='gridcell']</value>
      <webElementGuid>667bb3c6-52d6-4336-96ec-755555c12d8f</webElementGuid>
   </webElementProperties>
</WebElementEntity>
