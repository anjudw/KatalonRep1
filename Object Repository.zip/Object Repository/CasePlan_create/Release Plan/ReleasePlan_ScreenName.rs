<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ReleasePlan_ScreenName</name>
   <tag></tag>
   <elementGuidId>cd7c70b3-bd9b-428c-b82c-d1f9a98b8733</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div/s4-tooltip/div[@class='mat-tooltip-trigger s4-tooltip-host']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div/s4-tooltip/div[@class='mat-tooltip-trigger s4-tooltip-host']</value>
      <webElementGuid>5414313b-6260-40f4-ab97-60809b11f293</webElementGuid>
   </webElementProperties>
</WebElementEntity>
