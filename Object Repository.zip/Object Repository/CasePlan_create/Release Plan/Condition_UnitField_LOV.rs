<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Condition_UnitField_LOV</name>
   <tag></tag>
   <elementGuidId>e5087fe0-ebc2-4bab-932d-41dba019a8d4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div/ul/mat-option/span/li/span[2][contains(text(), &quot;HOURS&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div/ul/mat-option/span/li/span[2][contains(text(), &quot;HOURS&quot;)]</value>
      <webElementGuid>f33aa79a-597e-42d5-84f7-e8b2ef261444</webElementGuid>
   </webElementProperties>
</WebElementEntity>
