<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ReleasePlan_Grid_SaveButton</name>
   <tag></tag>
   <elementGuidId>8fdeab1c-ce7c-45f9-9e2f-8f6929c27f2f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div/button[@class='court-btn controls-btn save-btn' and @type='submit']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div/button[@class='court-btn controls-btn save-btn' and @type='submit']</value>
      <webElementGuid>3589a5da-9aa3-4ade-ba3e-67b6970f9b7e</webElementGuid>
   </webElementProperties>
</WebElementEntity>
