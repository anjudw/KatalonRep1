<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Conditions_SaveButton</name>
   <tag></tag>
   <elementGuidId>eddb49d3-cc55-49f5-b6ba-0a2f97763a76</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//mat-dialog-actions/div/s4-button/button/span[contains(text(), &quot;Save&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//mat-dialog-actions/div/s4-button/button/span[contains(text(), &quot;Save&quot;)]</value>
      <webElementGuid>0f25eeee-4277-4dd5-ae7d-2347cf0adad5</webElementGuid>
   </webElementProperties>
</WebElementEntity>
