<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>CaseManager_LOV</name>
   <tag></tag>
   <elementGuidId>0ee43f93-5f33-4c50-b70a-5a8cca139860</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//li/span[2][contains(text(), &quot;4630&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//li/span[2][contains(text(), &quot;4630&quot;)]</value>
      <webElementGuid>07f00b1b-4b6f-401a-a43b-fc07f9b9221f</webElementGuid>
   </webElementProperties>
</WebElementEntity>
