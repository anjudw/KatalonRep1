<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Release Plan Menu</name>
   <tag></tag>
   <elementGuidId>bf1e9d4f-1c32-430b-b2f9-efba750d526f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//li/mat-nav-list/a[@href='#/OIDRPLAN']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//li/mat-nav-list/a[@href='#/OIDRPLAN']</value>
      <webElementGuid>699a1076-01bd-4d5d-9767-5d422b1af545</webElementGuid>
   </webElementProperties>
</WebElementEntity>
