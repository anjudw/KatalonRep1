<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Conditions_UnitField</name>
   <tag></tag>
   <elementGuidId>6c24add0-2e58-42de-bdbf-4ed7f0c0103a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@col-id='lengthUnit' and @role='gridcell']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@col-id='lengthUnit' and @role='gridcell']</value>
      <webElementGuid>2218c47e-a8b5-481a-898e-e3b95834e360</webElementGuid>
   </webElementProperties>
</WebElementEntity>
