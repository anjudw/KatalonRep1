<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Conditions_conditionsField_LOV</name>
   <tag></tag>
   <elementGuidId>2fe42ab0-d1c1-4898-a892-607cf4cdcbad</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//li/span[contains(text(), &quot;PL1&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//li/span[contains(text(), &quot;PL1&quot;)]</value>
      <webElementGuid>88e4c935-e376-4fd9-8f80-670868639901</webElementGuid>
   </webElementProperties>
</WebElementEntity>
