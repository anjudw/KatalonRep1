<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Parole Agent</name>
   <tag></tag>
   <elementGuidId>72d258f1-5e6b-431a-b581-2e026392ffa3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@col-id='paroleAgentId' and @role='gridcell']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@col-id='paroleAgentId' and @role='gridcell']</value>
      <webElementGuid>57b2b3fa-3766-46f8-9631-9bfb9e4d6850</webElementGuid>
   </webElementProperties>
</WebElementEntity>
