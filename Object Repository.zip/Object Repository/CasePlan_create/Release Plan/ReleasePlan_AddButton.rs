<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ReleasePlan_AddButton</name>
   <tag></tag>
   <elementGuidId>5c5ed365-1d09-4f0e-a24b-9ace8e7d0b2d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div/button[@class=&quot;court-btn controls-btn add-btn&quot; and @type='submit']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div/button[@class=&quot;court-btn controls-btn add-btn&quot; and @type='submit']</value>
      <webElementGuid>66d28096-03d9-4ba3-9b9d-ee2ef42b2047</webElementGuid>
   </webElementProperties>
</WebElementEntity>
