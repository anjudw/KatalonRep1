<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Conditions_Category_LOV</name>
   <tag></tag>
   <elementGuidId>4ec517c0-36d1-49f5-972f-bc5e1c07035c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//li/span[2][contains(text(), &quot;CRT_REP&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//li/span[2][contains(text(), &quot;CRT_REP&quot;)]</value>
      <webElementGuid>58c1c29a-f78d-4930-919e-cf345e336db7</webElementGuid>
   </webElementProperties>
</WebElementEntity>
