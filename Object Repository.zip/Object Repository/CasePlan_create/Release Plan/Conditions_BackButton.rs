<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Conditions_BackButton</name>
   <tag></tag>
   <elementGuidId>2a0a91af-6682-4047-b7cc-a2a2c83ca909</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//mat-dialog-actions/div/s4-button/button/span[contains(text(), &quot;Back&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//mat-dialog-actions/div/s4-button/button/span[contains(text(), &quot;Back&quot;)]</value>
      <webElementGuid>14248153-3126-4b64-941b-9193289c7a61</webElementGuid>
   </webElementProperties>
</WebElementEntity>
