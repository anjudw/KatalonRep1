<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>PlanDetails_tab</name>
   <tag></tag>
   <elementGuidId>33ca3565-db9d-49f6-b5dd-eaaca829afcb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@role='tab' and @class=&quot;mat-ripple mat-tab-label mat-focus-indicator mat-tab-label-active ng-star-inserted&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@role='tab' and @class=&quot;mat-ripple mat-tab-label mat-focus-indicator mat-tab-label-active ng-star-inserted&quot;]</value>
      <webElementGuid>454af00b-36b1-448b-9fc6-b4af597bbc17</webElementGuid>
   </webElementProperties>
</WebElementEntity>
