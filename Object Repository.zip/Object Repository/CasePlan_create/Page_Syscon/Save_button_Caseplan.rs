<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Save_button_Caseplan</name>
   <tag></tag>
   <elementGuidId>784767d7-2327-4638-88bd-f709f8dfa25c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//button[@type='submit' and @class='court-btn controls-btn save-btn']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//button[@type='submit' and @class='court-btn controls-btn save-btn']</value>
      <webElementGuid>917b4e87-ceba-42eb-8591-1d37f6d5f445</webElementGuid>
   </webElementProperties>
</WebElementEntity>
