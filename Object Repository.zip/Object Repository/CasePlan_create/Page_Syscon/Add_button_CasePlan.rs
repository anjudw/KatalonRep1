<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Add_button_CasePlan</name>
   <tag></tag>
   <elementGuidId>7874a534-e4fb-4afc-8a5f-f6ada577759c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>button.court-btn.controls-btn.add-btn</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//s4-panel[@id='CAS_PLN']/div/div/div/mat-expansion-panel/div/div/div[2]/div/s4-grid/div/div[2]/div/div/div/div/button[@class='court-btn controls-btn add-btn']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//mat-expansion-panel[@id='CAS_PLN']/div/div/div[2]/div/s4-grid/div/div[2]/div/div/div/div/button[@type='submit' and @class='court-btn controls-btn add-btn']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//s4-panel[@id='CAS_PLN']/div/div/div/mat-expansion-panel/div/div/div[2]/div/s4-grid/div/div[2]/div/div/div/div/button[@class='court-btn controls-btn add-btn']</value>
      <webElementGuid>d1776895-55e0-443b-ae67-c46c21ce67f0</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//button[@type='submit']</value>
      <webElementGuid>b1815b80-d657-41c5-9858-13a150344dfd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>(//div[@id='gridContainer']/div[2]/div/div/div/div/button)[5]</value>
      <webElementGuid>d1c98808-540a-4c47-816e-385c6b923ad7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='of'])[4]/following::button[1]</value>
      <webElementGuid>0a98ee94-68ee-4d5d-95e2-005082a89376</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Page'])[2]/following::button[1]</value>
      <webElementGuid>30087e6f-59e3-4471-aad0-8c5f4572ba38</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Rows per page'])[2]/preceding::button[3]</value>
      <webElementGuid>b775f4cd-1de4-41ac-b79b-9b320ed742b6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//mat-expansion-panel/div/div/div[2]/div/s4-grid/div/div[2]/div/div/div/div/button</value>
      <webElementGuid>5efcb7db-8d11-43a9-aa2f-c3684dcca186</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[@type = 'submit' and (text() = '   ' or . = '   ')]</value>
      <webElementGuid>0787f1c3-d237-4a19-a03c-8613decd2ffc</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
