<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Primary Case Officer_checkbox</name>
   <tag></tag>
   <elementGuidId>3efe2c3c-925a-4242-a42d-e6bf1e66c129</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#mat-checkbox-19 > label.mat-checkbox-layout > span.mat-checkbox-inner-container.mat-checkbox-inner-container-no-side-margin</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='true'])[1]/preceding::span[17]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>89e1284e-46fe-464a-a09a-4a7525810737</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin</value>
      <webElementGuid>dc718c7d-6658-4585-910d-ba4a30ebdc5e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mat-checkbox-19&quot;)/label[@class=&quot;mat-checkbox-layout&quot;]/span[@class=&quot;mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin&quot;]</value>
      <webElementGuid>5abd4465-c942-4bcd-9136-05625ea802be</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//mat-checkbox[@id='mat-checkbox-19']/label/span</value>
      <webElementGuid>83199fa5-6284-4bfe-825a-e7529127222f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Primary Case Officer'])[1]/following::span[1]</value>
      <webElementGuid>bdab5ddc-7e56-4b26-8e1b-5b496ea9e5df</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='DWIVEDI, ANJU'])[1]/following::span[1]</value>
      <webElementGuid>69426d7b-080b-4569-8062-6e78ac620818</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='true'])[1]/preceding::span[17]</value>
      <webElementGuid>6af94ec9-be17-4dc7-afc5-b0fed217de87</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='to'])[5]/preceding::span[19]</value>
      <webElementGuid>69c97d98-758d-4a5f-ac42-12b8eab0c924</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/grid-cell-render-selectbox/mat-checkbox/label/span</value>
      <webElementGuid>0adbe2c2-d309-4264-9d10-7b5c9f512976</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
