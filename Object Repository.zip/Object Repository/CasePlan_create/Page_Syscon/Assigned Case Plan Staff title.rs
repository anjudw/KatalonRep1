<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Assigned Case Plan Staff title</name>
   <tag></tag>
   <elementGuidId>f86650f5-71c7-4849-be59-3029b1acc327</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.mat-tooltip-trigger.s4-tooltip-host > span</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//mat-dialog-container[@id='mat-dialog-1']/ocdiplaccomponent/s4-dialog-card/mat-toolbar/span/s4-tooltip/div/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>a65d55bd-41da-4f8d-9044-0afe4ed15944</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Assigned Case Plan Staff</value>
      <webElementGuid>6ffe3cbf-c8d4-44ec-b333-9cb58830f647</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mat-dialog-1&quot;)/ocdiplaccomponent[@class=&quot;ng-star-inserted&quot;]/s4-dialog-card[@class=&quot;s4-dialog-card&quot;]/mat-toolbar[@class=&quot;mat-toolbar dialog-toolbar mat-toolbar-single-row&quot;]/span[1]/s4-tooltip[@class=&quot;dialog-card-tooltip&quot;]/div[@class=&quot;mat-tooltip-trigger s4-tooltip-host&quot;]/span[1]</value>
      <webElementGuid>46f50c5e-3a61-44b0-a01d-739e7d98c505</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//mat-dialog-container[@id='mat-dialog-1']/ocdiplaccomponent/s4-dialog-card/mat-toolbar/span/s4-tooltip/div/span</value>
      <webElementGuid>f37eb5ac-ed44-4e77-83ff-364e54679083</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='OCDIPLAC'])[1]/following::span[2]</value>
      <webElementGuid>b466b888-af46-4c39-a150-35d455a64ae7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Document'])[1]/following::span[2]</value>
      <webElementGuid>7805fa09-d86d-4480-9966-d01d3e0beb6b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Drag here to set row groups'])[5]/preceding::span[3]</value>
      <webElementGuid>e58ad58d-4ff1-4eb4-b702-61d0ef326a37</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Drag here to set column labels'])[5]/preceding::span[5]</value>
      <webElementGuid>fc9db437-6ac0-4fed-8208-eaf3b6ebef2f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Assigned Case Plan Staff']/parent::*</value>
      <webElementGuid>574cd79d-4cd4-48a9-a197-c7c6e66cab77</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//s4-tooltip/div/span</value>
      <webElementGuid>cda2dc38-8009-4a28-8d19-d596b6899d95</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Assigned Case Plan Staff' or . = 'Assigned Case Plan Staff')]</value>
      <webElementGuid>a54d23cf-e459-4927-a3ba-fd89cb9a4bd3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
