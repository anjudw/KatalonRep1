<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>panel_Integrated Case Plan</name>
   <tag></tag>
   <elementGuidId>85d27f37-3900-4705-bdba-f758a8ee59a8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.s4-panel-margin > #CAS_PLN</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//mat-expansion-panel[@id='CAS_PLN']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>mat-expansion-panel</value>
      <webElementGuid>972738bf-cf04-4050-80f2-c3f339b476b9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mat-expansion-panel ng-tns-c182-7 mat-expanded ng-star-inserted</value>
      <webElementGuid>a9f20e97-804d-47fd-bfd3-1ed0758f01e8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>CAS_PLN</value>
      <webElementGuid>a98b4d19-38d2-4fd4-af36-898248d0032f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Integrated Case Plan  Requires Review
                Drag here to set row groupsDrag here to set column labels
                
                    
        
            
            
                
                
                    
                
            
        
            
            
                Create Date
                
                
                
                
                
            
        
            
                
                
                    
                
            
        
            
            
                Status
                
                
                
                
                
            
        
            
                
                
                    
                
            
        
            
            
                Custodial Location
                
                
                
                
                
            
        
            
                
                
                    
                
            
        
            
            
                Custodial Officer
                
                
                
                
                
            
        
            
                
                
                    
                
            
        
            
            
                Community Location
                
                
                
                
                
            
        
            
                
                
                    
                
            
        
            
            
                Officer
                
                
                
                
                
            
        
            
                
                
                    
                
            
        
            
            
                Supervision
                
                
                
                
                
            
        
            
                
                
                    
                
            
        
            
            
                Next Review Date
                
                
                
                
                
            
        
            
                
                
                    
                
            
        
            
            
                Verified
                
                
                
                
                
            
        
        
        
            
            
                
            
            
            
        
        
            
            
                
                    
                
            
            
            
        
        
            
            
                
            
            
            
        
        
            
            
                
            
            
        
        
            
                No Rows To Show
            
        
    
                    
            
        
                
                
            
            
            
        
                
                
                    
                    to
                    
                    of
                    
                
                
                    
                    
                    
                        Page
                        
                        of
                        
                    
                    
                    
                
            
                
                    
               
                     Rows per page  keyboard_arrow_down1 to 1 of 1first_pagekeyboard_arrow_leftkeyboard_arrow_rightlast_pageVerification.Upadate </value>
      <webElementGuid>78a60bda-f377-4246-9246-e9f9e08dd72d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;s4MainBody&quot;)/app-root[1]/app-home[@class=&quot;ng-star-inserted&quot;]/mat-sidenav-container[@class=&quot;mat-drawer-container mat-sidenav-container s4-sidenav-container main-menu-open mat-drawer-transition&quot;]/mat-sidenav-content[@class=&quot;mat-drawer-content mat-sidenav-content&quot;]/perfect-scrollbar[1]/div[@class=&quot;ps ps--active-y&quot;]/div[@class=&quot;ps-content&quot;]/main[1]/app-ocdiplan[@class=&quot;ng-star-inserted&quot;]/s4-pane[@id=&quot;casePlanHeader&quot;]/div[@class=&quot;s4-pane-inner&quot;]/div[@id=&quot;casePlanHeader&quot;]/div[@class=&quot;s4-pane-content&quot;]/div[1]/s4-panel[@id=&quot;CAS_PLN&quot;]/div[@class=&quot;s4-panel-card&quot;]/div[@class=&quot;s4-panel&quot;]/div[@class=&quot;s4-panel-margin&quot;]/mat-expansion-panel[@id=&quot;CAS_PLN&quot;]</value>
      <webElementGuid>d17fbc97-a56b-43a2-94cb-ac0516ee5032</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//mat-expansion-panel[@id='CAS_PLN']</value>
      <webElementGuid>cf78a357-bd82-4cca-b70b-148d82e12874</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//s4-panel[@id='CAS_PLN']/div/div/div/mat-expansion-panel</value>
      <webElementGuid>3c18c864-e0a4-4c38-9153-6fb44e5aa035</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Case Plan'])[3]/following::mat-expansion-panel[1]</value>
      <webElementGuid>4728ffb2-f8b4-41dd-9794-a52d219cc709</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//mat-expansion-panel</value>
      <webElementGuid>c440b4ea-b227-4701-8c56-f28d7e8649b4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//mat-expansion-panel[@id = 'CAS_PLN' and (text() = 'Integrated Case Plan  Requires Review
                Drag here to set row groupsDrag here to set column labels
                
                    
        
            
            
                
                
                    
                
            
        
            
            
                Create Date
                
                
                
                
                
            
        
            
                
                
                    
                
            
        
            
            
                Status
                
                
                
                
                
            
        
            
                
                
                    
                
            
        
            
            
                Custodial Location
                
                
                
                
                
            
        
            
                
                
                    
                
            
        
            
            
                Custodial Officer
                
                
                
                
                
            
        
            
                
                
                    
                
            
        
            
            
                Community Location
                
                
                
                
                
            
        
            
                
                
                    
                
            
        
            
            
                Officer
                
                
                
                
                
            
        
            
                
                
                    
                
            
        
            
            
                Supervision
                
                
                
                
                
            
        
            
                
                
                    
                
            
        
            
            
                Next Review Date
                
                
                
                
                
            
        
            
                
                
                    
                
            
        
            
            
                Verified
                
                
                
                
                
            
        
        
        
            
            
                
            
            
            
        
        
            
            
                
                    
                
            
            
            
        
        
            
            
                
            
            
            
        
        
            
            
                
            
            
        
        
            
                No Rows To Show
            
        
    
                    
            
        
                
                
            
            
            
        
                
                
                    
                    to
                    
                    of
                    
                
                
                    
                    
                    
                        Page
                        
                        of
                        
                    
                    
                    
                
            
                
                    
               
                     Rows per page  keyboard_arrow_down1 to 1 of 1first_pagekeyboard_arrow_leftkeyboard_arrow_rightlast_pageVerification.Upadate ' or . = 'Integrated Case Plan  Requires Review
                Drag here to set row groupsDrag here to set column labels
                
                    
        
            
            
                
                
                    
                
            
        
            
            
                Create Date
                
                
                
                
                
            
        
            
                
                
                    
                
            
        
            
            
                Status
                
                
                
                
                
            
        
            
                
                
                    
                
            
        
            
            
                Custodial Location
                
                
                
                
                
            
        
            
                
                
                    
                
            
        
            
            
                Custodial Officer
                
                
                
                
                
            
        
            
                
                
                    
                
            
        
            
            
                Community Location
                
                
                
                
                
            
        
            
                
                
                    
                
            
        
            
            
                Officer
                
                
                
                
                
            
        
            
                
                
                    
                
            
        
            
            
                Supervision
                
                
                
                
                
            
        
            
                
                
                    
                
            
        
            
            
                Next Review Date
                
                
                
                
                
            
        
            
                
                
                    
                
            
        
            
            
                Verified
                
                
                
                
                
            
        
        
        
            
            
                
            
            
            
        
        
            
            
                
                    
                
            
            
            
        
        
            
            
                
            
            
            
        
        
            
            
                
            
            
        
        
            
                No Rows To Show
            
        
    
                    
            
        
                
                
            
            
            
        
                
                
                    
                    to
                    
                    of
                    
                
                
                    
                    
                    
                        Page
                        
                        of
                        
                    
                    
                    
                
            
                
                    
               
                     Rows per page  keyboard_arrow_down1 to 1 of 1first_pagekeyboard_arrow_leftkeyboard_arrow_rightlast_pageVerification.Upadate ')]</value>
      <webElementGuid>d200bf07-5a42-4cd1-af05-9715e17e046c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
