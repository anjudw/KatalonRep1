<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>CasePlanRoleLOV</name>
   <tag></tag>
   <elementGuidId>13535238-0328-4a81-8b5d-abee5e881aec</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//li/span[contains(text(), &quot;Primary Case Officer&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//li/span[contains(text(), &quot;Primary Case Officer&quot;)]</value>
      <webElementGuid>1d74028f-9536-48d7-99f0-2159a4dee7a1</webElementGuid>
   </webElementProperties>
</WebElementEntity>
