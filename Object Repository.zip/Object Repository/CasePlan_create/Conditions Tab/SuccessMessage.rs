<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>SuccessMessage</name>
   <tag></tag>
   <elementGuidId>ce323930-0906-483f-946d-aaf49a175e13</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@class='toastHeading']/h3[contains(text(), &quot;Success!&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@class='toastHeading']/h3[contains(text(), &quot;Success!&quot;)]</value>
      <webElementGuid>4ed3bc27-6bdc-4445-b0a7-6dc5c3a3ba23</webElementGuid>
   </webElementProperties>
</WebElementEntity>
