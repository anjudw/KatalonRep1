<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ConditionsTab Header</name>
   <tag></tag>
   <elementGuidId>961413f7-e843-4646-8eea-e0725717b740</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@role='tab' and @class='mat-ripple mat-tab-label mat-focus-indicator ng-star-inserted' ]/div[contains(text(), &quot;Conditions&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@role='tab' and @class='mat-ripple mat-tab-label mat-focus-indicator ng-star-inserted' ]/div[contains(text(), &quot;Conditions&quot;)]</value>
      <webElementGuid>529f3cbc-255a-4305-bed8-9716d674c3b0</webElementGuid>
   </webElementProperties>
</WebElementEntity>
