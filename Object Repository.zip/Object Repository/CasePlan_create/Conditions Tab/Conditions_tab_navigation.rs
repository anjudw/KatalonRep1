<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Conditions_tab_navigation</name>
   <tag></tag>
   <elementGuidId>f4fc11d1-fe0c-4a55-baa5-318746d54489</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@role='tab']/div[@class=&quot;mat-tab-label-content&quot; and contains(text(), &quot;Conditions&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@role='tab']/div[@class=&quot;mat-tab-label-content&quot; and contains(text(), &quot;Conditions&quot;)]</value>
      <webElementGuid>765524e8-0a3a-44f8-b3f2-ac08cc35f6f7</webElementGuid>
   </webElementProperties>
</WebElementEntity>
