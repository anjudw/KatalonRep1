<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>POA_CaseworkField</name>
   <tag></tag>
   <elementGuidId>98d8d761-ea58-400f-a00a-495da2ab75af</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@col-id='caseworkType' and @role='gridcell']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@col-id='caseworkType' and @role='gridcell']</value>
      <webElementGuid>828aed27-e1ed-4a5c-835d-6113658300fd</webElementGuid>
   </webElementProperties>
</WebElementEntity>
