<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>POA_SaveButton</name>
   <tag></tag>
   <elementGuidId>06a63b6a-0406-40f4-adc6-063dace5f98a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div/button[@class='court-btn controls-btn save-btn' and @type='submit']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div/button[@class='court-btn controls-btn save-btn' and @type='submit']</value>
      <webElementGuid>ea4fa63d-704f-4560-99da-d3ed3c53ad9f</webElementGuid>
   </webElementProperties>
</WebElementEntity>
