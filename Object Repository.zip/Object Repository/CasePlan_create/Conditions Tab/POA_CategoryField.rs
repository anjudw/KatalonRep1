<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>POA_CategoryField</name>
   <tag></tag>
   <elementGuidId>ec36e9e9-9193-4e7c-b4c8-ad8aa99ee20f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@col-id='programCategory' and @role='gridcell']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@col-id='programCategory' and @role='gridcell']</value>
      <webElementGuid>348e9b65-92c6-443d-aea6-d1f0a5282c9b</webElementGuid>
   </webElementProperties>
</WebElementEntity>
