<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>POA_CaseworkField_LOV</name>
   <tag></tag>
   <elementGuidId>64fedb01-441e-4395-a7e4-e9572a949d7b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//li/span[2][contains(text(), &quot;FI&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//li/span[2][contains(text(), &quot;FI&quot;)]</value>
      <webElementGuid>14ec3fba-213b-46bb-9dec-77c564c9a4d0</webElementGuid>
   </webElementProperties>
</WebElementEntity>
