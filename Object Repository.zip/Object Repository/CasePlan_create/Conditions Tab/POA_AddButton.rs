<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>POA_AddButton</name>
   <tag></tag>
   <elementGuidId>4ddd3fbb-4878-414c-8dbf-38d1351b8204</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div/s4-grid [@id='offActionPlnV2'] /div/div/div/div/div/div/button[@type=&quot;submit&quot; and @class=&quot;court-btn controls-btn add-btn&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div/s4-grid [@id='offActionPlnV2'] /div/div/div/div/div/div/button[@type=&quot;submit&quot; and @class=&quot;court-btn controls-btn add-btn&quot;]</value>
      <webElementGuid>f4912f7e-78ab-419f-af30-846bff15f159</webElementGuid>
   </webElementProperties>
</WebElementEntity>
