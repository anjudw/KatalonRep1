<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Conditions_POA_AddButton</name>
   <tag></tag>
   <elementGuidId>99069175-25c1-46b6-82a2-fe2abe5c0ee1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//s4-tabgroup/mat-tab-group/div/mat-tab-body[2]/div/s4-panel/div/div/div/mat-expansion-panel/div/div/div[4]/div[2]/s4-grid/div/div[2]/div/div[1]/div/div[1]/button[@class='court-btn controls-btn add-btn']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//s4-tabgroup/mat-tab-group/div/mat-tab-body[2]/div/s4-panel/div/div/div/mat-expansion-panel/div/div/div[4]/div[2]/s4-grid/div/div[2]/div/div[1]/div/div[1]/button[@class='court-btn controls-btn add-btn']</value>
      <webElementGuid>849308d0-7d5a-425d-9ec8-27cf3a2e21a4</webElementGuid>
   </webElementProperties>
</WebElementEntity>
