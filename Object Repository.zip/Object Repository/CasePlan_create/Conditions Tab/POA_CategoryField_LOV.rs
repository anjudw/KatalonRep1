<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>POA_CategoryField_LOV</name>
   <tag></tag>
   <elementGuidId>1d3112f9-f1d4-4e60-9b7b-381a4aa3b31d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//li/span[2][contains(text(), &quot;WR&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//li/span[2][contains(text(), &quot;WR&quot;)]</value>
      <webElementGuid>db045b8e-d210-4f2e-ae81-bf66a41e5308</webElementGuid>
   </webElementProperties>
</WebElementEntity>
