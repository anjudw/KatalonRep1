<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>AssessedRisk_LOV</name>
   <tag></tag>
   <elementGuidId>7d38c795-0beb-4afb-994d-be1a5e0ba7ba</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//li/span[contains(text(), &quot;Aggression&quot;)]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>/html/body/div[3]/div/div/div/ul/mat-option[2]/span/li/span[contains(text(), &quot;Aggression&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//li/span[contains(text(), &quot;Aggression&quot;)]</value>
      <webElementGuid>5bba7ff8-2a24-47fe-88b9-c7d029e8f4d6</webElementGuid>
   </webElementProperties>
</WebElementEntity>
