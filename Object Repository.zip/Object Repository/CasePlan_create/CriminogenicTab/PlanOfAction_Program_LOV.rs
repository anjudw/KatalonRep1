<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>PlanOfAction_Program_LOV</name>
   <tag></tag>
   <elementGuidId>14df2ca2-240c-4fcd-a0fe-efc0d5f530c0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//li/span[2][contains(text(), &quot;3145&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//li/span[2][contains(text(), &quot;3145&quot;)]</value>
      <webElementGuid>66b66c35-1cd3-44ef-8ece-3cf71e6a0a10</webElementGuid>
   </webElementProperties>
</WebElementEntity>
