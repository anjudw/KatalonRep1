<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>PlanOfAction_Program_LOV_V2</name>
   <tag></tag>
   <elementGuidId>82021b8e-6ed0-4234-ba88-b58fa0d15427</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//li/span[2][contains(text(), &quot;2222&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//li/span[2][contains(text(), &quot;2222&quot;)]</value>
      <webElementGuid>46874f95-c800-4cf8-af23-5b94d168d3c2</webElementGuid>
   </webElementProperties>
</WebElementEntity>
