<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>PlanOfAction_SaveButton</name>
   <tag></tag>
   <elementGuidId>63f31d71-c21f-4a39-9793-5ac1109b609e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div/button[@class='court-btn controls-btn save-btn']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div/button[@class='court-btn controls-btn save-btn']</value>
      <webElementGuid>29a3fc53-61b1-48ec-a3aa-9dd7b5388295</webElementGuid>
   </webElementProperties>
</WebElementEntity>
