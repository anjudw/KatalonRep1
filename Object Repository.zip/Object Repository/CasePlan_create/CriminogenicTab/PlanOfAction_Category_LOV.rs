<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>PlanOfAction_Category_LOV</name>
   <tag></tag>
   <elementGuidId>2b6708c6-85e1-43c8-91d6-23199752ba87</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//li/span[2][contains(text(), &quot;INST_ACT&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//li/span[2][contains(text(), &quot;INST_ACT&quot;)]</value>
      <webElementGuid>338bbaff-c62c-4d0c-9be3-541560489fab</webElementGuid>
   </webElementProperties>
</WebElementEntity>
