<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>AssessedNeed_dropdown_listBox</name>
   <tag></tag>
   <elementGuidId>1ab620ec-0904-4cc4-abab-cbcf01e89ec9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div [@id='cdk-overlay-12']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div [@id='cdk-overlay-12']</value>
      <webElementGuid>010de347-024e-48ac-90b1-b46894fcaec0</webElementGuid>
   </webElementProperties>
</WebElementEntity>
