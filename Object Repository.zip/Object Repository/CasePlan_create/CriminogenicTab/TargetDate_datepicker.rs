<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>TargetDate_datepicker</name>
   <tag></tag>
   <elementGuidId>10fc312b-9abd-4a32-ad95-eb48748b1473</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id=&quot;caspln&quot;]/div/div[2]/div[2]/div[3]/div[2]/div/div/div/div[3]/grid-cell-editor-date/mat-form-field/div/div[1]/div[2][@class='mat-form-field-suffix ng-tns-c87-244 ng-star-inserted']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id=&quot;caspln&quot;]/div/div[2]/div[2]/div[3]/div[2]/div/div/div/div[3]/grid-cell-editor-date/mat-form-field/div/div[1]/div[2][@class='mat-form-field-suffix ng-tns-c87-244 ng-star-inserted']</value>
      <webElementGuid>76684d8d-bbe1-4486-a14a-7794b2ce398f</webElementGuid>
   </webElementProperties>
</WebElementEntity>
