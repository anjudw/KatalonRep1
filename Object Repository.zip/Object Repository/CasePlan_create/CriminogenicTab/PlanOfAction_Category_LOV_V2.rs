<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>PlanOfAction_Category_LOV_V2</name>
   <tag></tag>
   <elementGuidId>29aeb597-fc1a-4ee1-97bd-3054ae97c273</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//li/span[2][contains(text(), &quot;PWS&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//li/span[2][contains(text(), &quot;PWS&quot;)]</value>
      <webElementGuid>e650220f-75db-4959-907b-ab0cbe4b9f9b</webElementGuid>
   </webElementProperties>
</WebElementEntity>
