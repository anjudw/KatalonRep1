<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>PlanOfAction_Program</name>
   <tag></tag>
   <elementGuidId>672bd93f-788e-4d50-97ac-eb3be89a08da</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@col-id='programDesc' and @role='gridcell']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@col-id='programDesc' and @role='gridcell']</value>
      <webElementGuid>5f427d2b-41c7-4650-8069-3935648b9c8b</webElementGuid>
   </webElementProperties>
</WebElementEntity>
