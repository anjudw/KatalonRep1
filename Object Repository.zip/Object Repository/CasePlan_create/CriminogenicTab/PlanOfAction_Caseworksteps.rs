<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>PlanOfAction_Caseworksteps</name>
   <tag></tag>
   <elementGuidId>3dbb0aa9-5750-4032-8e95-efd5a3752522</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@col-id='caseworkType' and @role='gridcell']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@col-id='caseworkType' and @role='gridcell']</value>
      <webElementGuid>32707623-1d28-4d90-a6eb-d5d5e6b430e8</webElementGuid>
   </webElementProperties>
</WebElementEntity>
