<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>PlanOfAction_CancelButton</name>
   <tag></tag>
   <elementGuidId>3dcc2439-be35-4717-9ccf-2dda73299fba</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div/button[@class='court-btn controls-btn cancel-btn']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div/button[@class='court-btn controls-btn cancel-btn']</value>
      <webElementGuid>1fe581f3-40d0-4650-9ab5-3771e34fa9a1</webElementGuid>
   </webElementProperties>
</WebElementEntity>
