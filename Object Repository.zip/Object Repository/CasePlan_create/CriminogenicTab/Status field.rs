<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Status field</name>
   <tag></tag>
   <elementGuidId>0ae3a388-df84-457b-ac52-ea68484bd3f2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@col-id='statusCode' and @role='gridcell']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@col-id='statusCode' and @role='gridcell']</value>
      <webElementGuid>74560181-aac6-4ec9-8b3c-2491425b02fa</webElementGuid>
   </webElementProperties>
</WebElementEntity>
