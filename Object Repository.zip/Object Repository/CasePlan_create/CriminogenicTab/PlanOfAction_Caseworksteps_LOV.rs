<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>PlanOfAction_Caseworksteps_LOV</name>
   <tag></tag>
   <elementGuidId>2447dbb0-0508-4c5d-8edb-71db44590000</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//li/span[contains(text(), &quot;Education&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//li/span[contains(text(), &quot;Education&quot;)]</value>
      <webElementGuid>9364d7d1-131c-4f78-a3a0-9a00a9517918</webElementGuid>
   </webElementProperties>
</WebElementEntity>
