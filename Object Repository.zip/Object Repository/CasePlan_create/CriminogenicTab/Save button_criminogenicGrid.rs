<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Save button_criminogenicGrid</name>
   <tag></tag>
   <elementGuidId>6753b882-c6ca-491a-9a0c-264a49be526b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div/button[@class='court-btn controls-btn save-btn']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div/button[@class='court-btn controls-btn save-btn']</value>
      <webElementGuid>1a1bfe6f-50cb-4875-b5f6-a30cc7a18bdc</webElementGuid>
   </webElementProperties>
</WebElementEntity>
