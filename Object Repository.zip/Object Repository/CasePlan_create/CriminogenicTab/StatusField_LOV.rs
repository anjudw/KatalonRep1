<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>StatusField_LOV</name>
   <tag></tag>
   <elementGuidId>87b62565-abda-4f1e-bc50-8d0f60e476c6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//li/span[contains(text(), &quot;Active&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//li/span[contains(text(), &quot;Active&quot;)]</value>
      <webElementGuid>3adcdd38-c0d2-4637-9137-1e7d3302459e</webElementGuid>
   </webElementProperties>
</WebElementEntity>
