<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>TabHeader_CasePlan</name>
   <tag></tag>
   <elementGuidId>ee2897e3-c2f7-4094-ae82-26b1157a154e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//mat-tab-header [@class='mat-tab-header']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//mat-tab-header [@class='mat-tab-header']</value>
      <webElementGuid>e57a4e17-746e-4dd8-a082-ce4ebd1eefa5</webElementGuid>
   </webElementProperties>
</WebElementEntity>
