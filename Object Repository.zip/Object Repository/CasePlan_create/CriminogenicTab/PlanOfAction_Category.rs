<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>PlanOfAction_Category</name>
   <tag></tag>
   <elementGuidId>c49faf58-a71a-4282-a328-7117e187d039</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@col-id='programCategory' and @role='gridcell']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@col-id='programCategory' and @role='gridcell']</value>
      <webElementGuid>2155bd14-e650-4c7c-9db8-97a66feac3fb</webElementGuid>
   </webElementProperties>
</WebElementEntity>
