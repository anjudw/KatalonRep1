<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>WarningToast</name>
   <tag></tag>
   <elementGuidId>d35fea13-d5e0-4224-be9e-4611e863cfd8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@class='toastHeading']/h3[contains(text(), &quot;Warning!&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@class='toastHeading']/h3[contains(text(), &quot;Warning!&quot;)]</value>
      <webElementGuid>420e7779-0d7e-4400-9469-2ba2534d6c38</webElementGuid>
   </webElementProperties>
</WebElementEntity>
