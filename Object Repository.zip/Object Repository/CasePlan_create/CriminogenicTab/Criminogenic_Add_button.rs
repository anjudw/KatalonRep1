<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Criminogenic_Add_button</name>
   <tag></tag>
   <elementGuidId>c7f81ed8-2440-4348-9e58-8f9794817e48</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id=&quot;caspln&quot;]/div/div[2]/div/div[1]/div/div[1]/button[@type='submit' and @class='court-btn controls-btn add-btn']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id=&quot;caspln&quot;]/div/div[2]/div/div[1]/div/div[1]/button[@type='submit' and @class='court-btn controls-btn add-btn']</value>
      <webElementGuid>04d21008-e0e6-40d7-a579-6451c90a4c44</webElementGuid>
   </webElementProperties>
</WebElementEntity>
