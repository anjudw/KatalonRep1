<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>TargetDate</name>
   <tag></tag>
   <elementGuidId>ec4fb117-d0cb-4d75-a8a6-c3c022bc5380</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@col-id='targetDate' and @role='gridcell']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@col-id='targetDate' and @role='gridcell']</value>
      <webElementGuid>ee28778c-6578-4837-a0d7-bc700921b603</webElementGuid>
   </webElementProperties>
</WebElementEntity>
