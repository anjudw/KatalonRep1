<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ObjectiveField</name>
   <tag></tag>
   <elementGuidId>6d38a91b-0559-490c-99ae-da90b97a6802</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value> //*[@id=&quot;caspln&quot;]/div/div[2]/div[2]/div[3]/div[2]/div/div/div/div[2][@col-id='objective']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value> //*[@id=&quot;caspln&quot;]/div/div[2]/div[2]/div[3]/div[2]/div/div/div/div[2][@col-id='objective']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value> //*[@id=&quot;caspln&quot;]/div/div[2]/div[2]/div[3]/div[2]/div/div/div/div[2][@col-id='objective']</value>
      <webElementGuid>2d758c54-755a-4d5e-a777-f27290a43ba0</webElementGuid>
   </webElementProperties>
</WebElementEntity>
