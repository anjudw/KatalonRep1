<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>PlanOfAction_DeleteButton</name>
   <tag></tag>
   <elementGuidId>91432826-72c9-442a-946f-63c2b3529c79</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div/button[@class='court-btn controls-btn delete-btn']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div/button[@class='court-btn controls-btn delete-btn']</value>
      <webElementGuid>f8b1f73c-653e-4da8-b8aa-103632041578</webElementGuid>
   </webElementProperties>
</WebElementEntity>
