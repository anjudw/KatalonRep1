<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>AssessedNeed_field</name>
   <tag></tag>
   <elementGuidId>36548dd2-c5d2-4ada-b4c4-1ed3cab30e03</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//input[@type='text' and @id='mat-input-41']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//input[@type='text' and @id='mat-input-41']</value>
      <webElementGuid>dfa71dc9-c3a2-491d-ae29-439fd21bba78</webElementGuid>
   </webElementProperties>
</WebElementEntity>
