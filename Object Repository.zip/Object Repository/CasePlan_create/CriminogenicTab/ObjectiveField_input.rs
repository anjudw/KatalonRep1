<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ObjectiveField_input</name>
   <tag></tag>
   <elementGuidId>29387447-7b68-41fe-b37b-007af4e2d7b1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//input[@class='ag-input-field-input ag-text-field-input']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//input[@class='ag-input-field-input ag-text-field-input']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//input[@class='ag-input-field-input ag-text-field-input']</value>
      <webElementGuid>7aac92c1-2022-4daf-af28-5c469aedf54c</webElementGuid>
   </webElementProperties>
</WebElementEntity>
