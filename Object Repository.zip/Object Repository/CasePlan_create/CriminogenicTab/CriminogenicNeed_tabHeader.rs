<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>CriminogenicNeed_tabHeader</name>
   <tag></tag>
   <elementGuidId>0fd843d9-8789-4006-9947-d4845c6708b2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@role='tab' and @id='mat-tab-label-0-0']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@role='tab' and @id='mat-tab-label-0-0']</value>
      <webElementGuid>6c96eb5f-69cf-4006-8063-8539fbff6bac</webElementGuid>
   </webElementProperties>
</WebElementEntity>
