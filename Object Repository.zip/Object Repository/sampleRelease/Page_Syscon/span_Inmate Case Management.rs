<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Inmate Case Management</name>
   <tag></tag>
   <elementGuidId>f01748a4-f996-4f6c-8a1b-1f700d1f6a94</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.menu-second-li.ng-star-inserted > mat-nav-list.mat-nav-list.mat-list-base.simpleTextLevel.ng-star-inserted > a.mat-list-item.mat-focus-indicator.active-link > span.mat-list-item-content > span.mat-list-text > span.mat-line.dynamic-menu-text</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//body[@id='s4MainBody']/app-root/app-home/mat-sidenav-container/mat-sidenav/div/div/perfect-scrollbar/div/div/dynamic-menu/div/ul/li/ul/li/mat-nav-list/a/span/span[2]/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>c20567a7-700d-4015-ad60-414a98ec0b4e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mat-line dynamic-menu-text</value>
      <webElementGuid>53d3d475-e126-4e3f-b295-55bfd6b50def</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Inmate Case Management</value>
      <webElementGuid>a64b6d9c-9bf3-4556-afe1-6e589b90b000</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;s4MainBody&quot;)/app-root[1]/app-home[@class=&quot;ng-star-inserted&quot;]/mat-sidenav-container[@class=&quot;mat-drawer-container mat-sidenav-container s4-sidenav-container main-menu-open mat-drawer-transition&quot;]/mat-sidenav[@class=&quot;mat-drawer mat-sidenav ng-tns-c226-5 ng-trigger ng-trigger-transform mat-drawer-side ng-star-inserted mat-drawer-opened&quot;]/div[@class=&quot;mat-drawer-inner-container ng-tns-c226-5&quot;]/div[@class=&quot;content-container ng-tns-c226-5&quot;]/perfect-scrollbar[1]/div[@class=&quot;ps ps--active-y&quot;]/div[@class=&quot;ps-content&quot;]/dynamic-menu[1]/div[@class=&quot;dynamic-menu&quot;]/ul[@class=&quot;level0 level&quot;]/li[@class=&quot;menu-first-li ng-star-inserted active-link&quot;]/ul[@class=&quot;level1 level ng-star-inserted&quot;]/li[@class=&quot;menu-second-li ng-star-inserted&quot;]/mat-nav-list[@class=&quot;mat-nav-list mat-list-base simpleTextLevel ng-star-inserted&quot;]/a[@class=&quot;mat-list-item mat-focus-indicator active-link&quot;]/span[@class=&quot;mat-list-item-content&quot;]/span[@class=&quot;mat-list-text&quot;]/span[@class=&quot;mat-line dynamic-menu-text&quot;]</value>
      <webElementGuid>371d9ff2-73fd-4c15-b10c-9294294ad061</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//body[@id='s4MainBody']/app-root/app-home/mat-sidenav-container/mat-sidenav/div/div/perfect-scrollbar/div/div/dynamic-menu/div/ul/li/ul/li/mat-nav-list/a/span/span[2]/span</value>
      <webElementGuid>e39e82b2-5e83-4477-b85e-6eb6c2b09cd8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='keyboard_arrow_up'])[1]/following::span[4]</value>
      <webElementGuid>c900673b-34ed-4fb2-95c2-95c403fd7c6c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Modules'])[1]/following::span[4]</value>
      <webElementGuid>50a7b70e-473c-4053-9e74-0612a3216238</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='System Search'])[1]/preceding::span[2]</value>
      <webElementGuid>146f699c-2ff5-4205-a5f9-3ae62c7ab0d9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Name'])[1]/preceding::span[6]</value>
      <webElementGuid>588cd6c5-2cff-4f63-9b8e-5a56f58449c5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Inmate Case Management']/parent::*</value>
      <webElementGuid>b66fc26d-7ca4-46af-942d-be741feb485c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li/ul/li/mat-nav-list/a/span/span[2]/span</value>
      <webElementGuid>f5c1ec98-d778-4fa4-b1ba-81a679e3ac35</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Inmate Case Management' or . = 'Inmate Case Management')]</value>
      <webElementGuid>9fbdb86c-5153-414a-84cf-bdc3e71724d1</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
