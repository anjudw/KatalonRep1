<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Case Management</name>
   <tag></tag>
   <elementGuidId>698c64b1-95bb-4f4b-9265-d4b37d291ddb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//body[@id='s4MainBody']/app-root/app-home/mat-sidenav-container/mat-sidenav/div/div/perfect-scrollbar/div/div/dynamic-menu/div/ul/li/ul/li/ul/li[8]/mat-nav-list/a/span/span[2]/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>6c9335d3-d517-40be-9bff-5be28b826525</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mat-line dynamic-menu-text</value>
      <webElementGuid>0de232a3-5fb0-482c-8ca3-ec7d31071873</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Case Management</value>
      <webElementGuid>d52e56a1-3be2-42f6-a58b-464377f2eb71</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;s4MainBody&quot;)/app-root[1]/app-home[@class=&quot;ng-star-inserted&quot;]/mat-sidenav-container[@class=&quot;mat-drawer-container mat-sidenav-container s4-sidenav-container main-menu-open mat-drawer-transition&quot;]/mat-sidenav[@class=&quot;mat-drawer mat-sidenav ng-tns-c226-5 ng-trigger ng-trigger-transform mat-drawer-side ng-star-inserted mat-drawer-opened&quot;]/div[@class=&quot;mat-drawer-inner-container ng-tns-c226-5&quot;]/div[@class=&quot;content-container ng-tns-c226-5&quot;]/perfect-scrollbar[1]/div[@class=&quot;ps ps--active-y&quot;]/div[@class=&quot;ps-content&quot;]/dynamic-menu[1]/div[@class=&quot;dynamic-menu&quot;]/ul[@class=&quot;level0 level&quot;]/li[@class=&quot;menu-first-li ng-star-inserted active-link&quot;]/ul[@class=&quot;level1 level ng-star-inserted&quot;]/li[@class=&quot;menu-second-li ng-star-inserted&quot;]/ul[@class=&quot;level2 level ng-star-inserted&quot;]/li[@class=&quot;menu-third-li ng-star-inserted&quot;]/mat-nav-list[@class=&quot;mat-nav-list mat-list-base simpleTextLevel ng-star-inserted&quot;]/a[@class=&quot;mat-list-item mat-focus-indicator&quot;]/span[@class=&quot;mat-list-item-content&quot;]/span[@class=&quot;mat-list-text&quot;]/span[@class=&quot;mat-line dynamic-menu-text&quot;]</value>
      <webElementGuid>aa86cca7-cedf-4da8-a92a-84af59e13643</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//body[@id='s4MainBody']/app-root/app-home/mat-sidenav-container/mat-sidenav/div/div/perfect-scrollbar/div/div/dynamic-menu/div/ul/li/ul/li/ul/li[8]/mat-nav-list/a/span/span[2]/span</value>
      <webElementGuid>132afa2b-bbef-47d1-a6a5-ccc135e07b1c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='housing location history'])[1]/following::span[4]</value>
      <webElementGuid>7a6ee62b-2b52-4e32-9d70-45d88fe18cde</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Internal Location OCUINTLC'])[1]/following::span[8]</value>
      <webElementGuid>9c3e68b7-3417-4518-8764-a62aa80d9917</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Case Notes'])[1]/preceding::span[2]</value>
      <webElementGuid>51092ebc-5109-4c25-a31d-94e704d9057e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Case Plan'])[1]/preceding::span[6]</value>
      <webElementGuid>7eae187f-8de3-41b4-b328-98b0fd9f466f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Case Management']/parent::*</value>
      <webElementGuid>47f1e566-2407-4676-bd2b-8c88d8a40969</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li/ul/li/ul/li[8]/mat-nav-list/a/span/span[2]/span</value>
      <webElementGuid>8d9c4171-6181-46e6-a82c-43b9c6d9e668</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Case Management' or . = 'Case Management')]</value>
      <webElementGuid>1a8081a0-c4b9-4e1c-998b-6809e78e675f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
