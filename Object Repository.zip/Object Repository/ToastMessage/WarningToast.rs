<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>WarningToast</name>
   <tag></tag>
   <elementGuidId>8784d494-cf8c-4dd2-b660-1f383a0b174d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@class='toastHeading']/h3[contains(text(), &quot;Warning!&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@class='toastHeading']/h3[contains(text(), &quot;Warning!&quot;)]</value>
      <webElementGuid>617310ef-b4df-47df-bf71-3fa6689c999d</webElementGuid>
   </webElementProperties>
</WebElementEntity>
