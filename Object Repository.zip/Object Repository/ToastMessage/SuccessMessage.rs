<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>SuccessMessage</name>
   <tag></tag>
   <elementGuidId>34b13718-5591-4c25-a07c-dc2446856b96</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@class='toastHeading']/h3[contains(text(), &quot;Success!&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@class='toastHeading']/h3[contains(text(), &quot;Success!&quot;)]</value>
      <webElementGuid>9f60384c-0a55-4670-b9e8-9980c0c79fa2</webElementGuid>
   </webElementProperties>
</WebElementEntity>
