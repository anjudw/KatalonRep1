<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Create New Offender Record</name>
   <tag></tag>
   <elementGuidId>4a64ff98-52d8-4725-a71f-d5d96f92eb8e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#coffibtn > span.mat-button-wrapper</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//button[@id='coffibtn']/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>c454b953-253d-4794-8e10-8a3335ff85d8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mat-button-wrapper</value>
      <webElementGuid>47e4b754-3a59-40e6-b071-1adf84442749</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Create New Offender Record</value>
      <webElementGuid>fd9a7276-c28f-4046-9ad0-b19082f9a1d9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;cdk-accordion-child-1&quot;)/div[@class=&quot;mat-expansion-panel-body ng-tns-c182-11&quot;]/form[@class=&quot;ng-tns-c182-11 ng-dirty ng-valid ng-touched ng-submitted&quot;]/div[4]/div[@class=&quot;offCreateBtn&quot;]/div[1]/s4-launchbutton[@id=&quot;coffibtn&quot;]/s4-button[@class=&quot;enabledLink&quot;]/button[@id=&quot;coffibtn&quot;]/span[@class=&quot;mat-button-wrapper&quot;]</value>
      <webElementGuid>554ec5d5-ac33-4550-97e0-7b38fce23e4f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//button[@id='coffibtn']/span</value>
      <webElementGuid>913468aa-3000-4e4b-acb3-d5d219528a11</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Clear'])[1]/following::span[3]</value>
      <webElementGuid>deaf748a-646b-4994-be40-4230b6318edf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Retrieve'])[2]/following::span[6]</value>
      <webElementGuid>1c7123d9-e84d-4e22-8681-754efd3b0e3c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Search'])[1]/preceding::span[3]</value>
      <webElementGuid>2646363c-e882-44e1-8c1c-e3db5dda05ac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='My Task'])[1]/preceding::span[3]</value>
      <webElementGuid>fdb65bb7-92db-4daf-b76f-fb701f15756f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Create New Offender Record']/parent::*</value>
      <webElementGuid>843bae13-4ee8-49ac-9e99-89bf4622666e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/s4-launchbutton/s4-button/button/span</value>
      <webElementGuid>e51f82b8-b06b-4f21-a44e-7209700dcdfe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = ' Create New Offender Record' or . = ' Create New Offender Record')]</value>
      <webElementGuid>d763bb77-a260-48a1-8de5-6a78976ee5fd</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
