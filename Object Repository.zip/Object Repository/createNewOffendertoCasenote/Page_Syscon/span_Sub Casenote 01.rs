<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Sub Casenote 01</name>
   <tag></tag>
   <elementGuidId>0b62f840-04f9-4321-9cc5-c55658bb2078</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#mat-option-299 > span.mat-option-text > li > span.ng-star-inserted</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Code'])[1]/following::span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>00abb444-657d-4100-afc9-239120396114</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ng-star-inserted</value>
      <webElementGuid>6dc36081-d317-49bf-a051-454032fe321c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Sub Casenote 01</value>
      <webElementGuid>a3757c5f-0bf2-44db-bb07-5bf1eeaa2654</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mat-option-299&quot;)/span[@class=&quot;mat-option-text&quot;]/li[1]/span[@class=&quot;ng-star-inserted&quot;]</value>
      <webElementGuid>3705af8c-db77-4943-b6be-6d111b639bab</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//mat-option[@id='mat-option-299']/span/li/span</value>
      <webElementGuid>3c297f0f-c765-422b-87ed-4f7249904314</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Code'])[1]/following::span[2]</value>
      <webElementGuid>0c1b7ce7-66b1-43a5-8d04-333d4b03f899</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Description'])[1]/following::span[3]</value>
      <webElementGuid>4181b0cc-c85d-4d1c-a113-5aae46a04dae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SCN01'])[1]/preceding::span[1]</value>
      <webElementGuid>c6a2d9ec-7c5a-45bf-860a-665a883c9372</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sub Casenote 02'])[1]/preceding::span[2]</value>
      <webElementGuid>67e3ca6a-6e33-43a7-87df-3f1578ee77d5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Sub Casenote 01']/parent::*</value>
      <webElementGuid>5c52b3a7-633e-4670-864b-04365791ca03</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//mat-option[2]/span/li/span</value>
      <webElementGuid>beeefbd7-a0bf-4377-8813-f0fdeaa8fd9b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Sub Casenote 01' or . = 'Sub Casenote 01')]</value>
      <webElementGuid>153d258f-f22b-4ea7-abff-5294466c7917</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
