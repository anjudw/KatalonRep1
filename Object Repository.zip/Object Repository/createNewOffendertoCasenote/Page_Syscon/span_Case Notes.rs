<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Case Notes</name>
   <tag></tag>
   <elementGuidId>bbbdf1fe-ad9a-4f4b-9c35-6d4cd1536274</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//body[@id='s4MainBody']/app-root/app-home/mat-sidenav-container/mat-sidenav/div/div/perfect-scrollbar/div/div/dynamic-menu/div/ul/li/ul/li/ul/li[8]/ul/li/mat-nav-list/a/span/span[2]/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>9b0e976b-5e39-444c-9afc-6c8566fb0257</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mat-line dynamic-menu-text</value>
      <webElementGuid>0534864d-5b58-4dca-91fe-65ccc3f17e6b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Case Notes</value>
      <webElementGuid>cc0cdca0-88af-445f-be3e-84523613ec36</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;s4MainBody&quot;)/app-root[1]/app-home[@class=&quot;ng-star-inserted&quot;]/mat-sidenav-container[@class=&quot;mat-drawer-container mat-sidenav-container s4-sidenav-container main-menu-open mat-drawer-transition&quot;]/mat-sidenav[@class=&quot;mat-drawer mat-sidenav ng-tns-c226-5 ng-trigger ng-trigger-transform mat-drawer-side ng-star-inserted mat-drawer-opened&quot;]/div[@class=&quot;mat-drawer-inner-container ng-tns-c226-5&quot;]/div[@class=&quot;content-container ng-tns-c226-5&quot;]/perfect-scrollbar[1]/div[@class=&quot;ps ps--active-y&quot;]/div[@class=&quot;ps-content&quot;]/dynamic-menu[1]/div[@class=&quot;dynamic-menu&quot;]/ul[@class=&quot;level0 level&quot;]/li[@class=&quot;menu-first-li ng-star-inserted active-link&quot;]/ul[@class=&quot;level1 level ng-star-inserted&quot;]/li[@class=&quot;menu-second-li ng-star-inserted&quot;]/ul[@class=&quot;level2 level ng-star-inserted&quot;]/li[@class=&quot;menu-third-li ng-star-inserted&quot;]/ul[@class=&quot;level3 level ng-star-inserted&quot;]/li[@class=&quot;menu-fourth-li ng-star-inserted&quot;]/mat-nav-list[@class=&quot;mat-nav-list mat-list-base redirectLinkLevel ng-star-inserted&quot;]/a[@class=&quot;mat-list-item mat-focus-indicator mat-list-item-avatar mat-list-item-with-avatar&quot;]/span[@class=&quot;mat-list-item-content&quot;]/span[@class=&quot;mat-list-text&quot;]/span[@class=&quot;mat-line dynamic-menu-text&quot;]</value>
      <webElementGuid>d0a4c20f-4c4c-47c6-8f77-18ef8d462a3a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//body[@id='s4MainBody']/app-root/app-home/mat-sidenav-container/mat-sidenav/div/div/perfect-scrollbar/div/div/dynamic-menu/div/ul/li/ul/li/ul/li[8]/ul/li/mat-nav-list/a/span/span[2]/span</value>
      <webElementGuid>aaee3900-fb4a-4009-9f7f-fbf333f57313</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Case Management'])[1]/following::span[4]</value>
      <webElementGuid>2e5ff5e3-6e5c-4a51-9d1e-5aeb4afdf857</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='housing location history'])[1]/following::span[8]</value>
      <webElementGuid>c993c594-1320-492b-8c5e-1782458c4a13</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Case Plan'])[1]/preceding::span[2]</value>
      <webElementGuid>67bd2ed2-3c45-4177-89b0-4dd7b719689d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Keep Separates'])[1]/preceding::span[6]</value>
      <webElementGuid>bf9ac16f-4f27-468c-95e0-a47212318230</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Case Notes']/parent::*</value>
      <webElementGuid>0d8ff5e0-5baf-492e-a853-d9db612f285a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li/ul/li/ul/li[8]/ul/li/mat-nav-list/a/span/span[2]/span</value>
      <webElementGuid>37fcae5a-0b5e-41ec-be13-a83250a94c35</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Case Notes' or . = 'Case Notes')]</value>
      <webElementGuid>55ca2338-0e79-4208-92fa-9731b9f8fc38</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
